extends Node

@onready var bg_music: AudioStreamPlayer = $AudioStreamPlayer
var umbrellaTune = load("res://Sounds/UmbrellaTune.mp3")
var danger = load("res://Sounds/Danger!Danger!.mp3")


var playing = false

func play_bg_music():
	if not playing:
		bg_music.stream = umbrellaTune
		bg_music.volume_db = -5.211
		bg_music.play()
		playing = true

func stop_bg_music():
	var lowerTween = get_tree().create_tween()
	lowerTween.tween_property(bg_music, "volume_db", -20, 5)
	bg_music.stop()

func play_danger_music():
	playing=false
	bg_music.volume_db = 0
	bg_music.stream = danger
	bg_music.play()

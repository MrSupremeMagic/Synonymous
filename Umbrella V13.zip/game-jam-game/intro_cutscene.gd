extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	AudioController.play_danger_music()
	var fadein = get_tree().create_tween()
	fadein.tween_property($Background4, "modulate", Color("00000000"), 1)
	await get_tree().create_timer(2).timeout
	
	var bird = get_tree().create_tween()
	bird.tween_property($Bird, "position", Vector2(-300, 345), 5)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_just_pressed("ui_accept"):
		var fadeout = get_tree().create_tween()
		fadeout.tween_property($Background4, "modulate", Color("000000ff"), 1)
		await get_tree().create_timer(1).timeout
		get_tree().change_scene_to_file("res://Level_1.tscn")


func _on_area_2d_body_entered(body: Node2D) -> void:
	$RigidBody2D.set_deferred("freeze", false)
	await get_tree().create_timer(2).timeout
	var fadeout = get_tree().create_tween()
	fadeout.tween_property($Background4, "modulate", Color("000000ff"), 1)
	await get_tree().create_timer(4).timeout
	AudioController.stop_bg_music()
	get_tree().change_scene_to_file("res://Level_1.tscn")

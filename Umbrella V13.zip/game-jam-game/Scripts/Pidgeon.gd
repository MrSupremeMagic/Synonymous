extends CharacterBody2D

@onready var anim = $AnimatedSprite2D
@onready var raycast = $ShapeCast2D
@onready var playerPos = get_node("../../Umbrella")


var projectileScene = preload("res://projectile.tscn")
var playerDetected = false
var attacking = false
var hovering = false
var pointA:Vector2 = Vector2(0, position.y)
var pointB:Vector2 = Vector2(100, position.y)
var currentPoint = "A"
var shitcooldown = 100
var dead=false

const AIR_RES = 0.15

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	velocity = Vector2(100,0)
	

func _physics_process(delta: float) -> void: #When is this called bro??? - X34
	if not dead:
		if not attacking:
			anim.play("Walk")
			if currentPoint=="A" and position.x > pointB.x:
				currentPoint="B"
				velocity.x = -100
				scale.x = -1
			if currentPoint=="B" and position.x < pointA.x:
				currentPoint = "A"
				velocity.x = 100
				scale.x = -1
			
			
			if raycast.is_colliding():
				attacking = true
		else:
			if is_on_floor():
				velocity.y = -300
		
		#egg code
		if attacking:
			if abs(global_position.x - playerPos.position.x) < 100  and playerPos.position.y > global_position.y + 30 and shitcooldown == 0:
				launch()
			if currentPoint=="A" and playerPos.position.x < global_position.x:
				scale.x = -1
				currentPoint = "B"
			if currentPoint=="B" and playerPos.position.x > global_position.x:
				scale.x = -1
				currentPoint = "A"
		
		if not is_on_floor():
			anim.play("Fly")
			var acceleration = [0, 0]
			
			#Try to hover a bit above or smth - X34
			acceleration[1] += get_gravity().y
			if anim.frame == 1: #Do not go up more than 25k - X34
				if global_position.y > playerPos.position.y - 175:
					acceleration[1] -= 2400
				else:
					acceleration[1] -= 1800
			
			#Try to get close but not too close
			if anim.frame == 1: #Try to stay 50 away or smth - X34
				if global_position.x + 50 < playerPos.position.x:
					acceleration[0] += 250
				elif global_position.x - 50 > playerPos.position.x:
					acceleration[0] -= 250
				elif global_position.x < playerPos.position.x:
					acceleration[0] -= 350
				else:
					acceleration[0] += 350
			
			#self stabilisation (not air resistance) - X34
			acceleration[0] -= velocity.x/2
			acceleration[1] -= velocity.y*2
			
			#air resistance - X34
			acceleration[0] -= velocity.x*AIR_RES
			acceleration[1] -= velocity.y*AIR_RES
			
			
			velocity.x += acceleration[0]*delta
			velocity.y += acceleration[1]*delta
	if dead:
		$CollisionShape2D.disabled = true
		$Area2D/CollisionShape2D.disabled = true
		velocity = Vector2(0, 300)
		var spinny = get_tree().create_tween()
		spinny.tween_property($".", "rotation", 100, 10)

	move_and_slide()

func launch():
	shitcooldown+=200
	var projectile = projectileScene.instantiate()
	get_tree().current_scene.add_child(projectile)
	projectile.position = Vector2(global_position.x, global_position.y + 10)
	


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if shitcooldown > 0:
		shitcooldown -= 1


func _on_area_2d_body_entered(body: Node2D) -> void:
	print("body entered")
	dead = true

extends Control


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	AudioController.play_bg_music()


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_start_pressed() -> void:
	$AudioStreamPlayer2D.play()
	start_sequence1()

func start_sequence1() -> void:
	var fadeTween = get_tree().create_tween()
	fadeTween.tween_property($Slide1, "modulate", Color("ffffff00") , 0.5)
	var slideTween = get_tree().create_tween()
	slideTween.tween_property($Slide2, "position", Vector2(0, -716.0) , 1)




func _on_umbrella_button_down() -> void:
	var fadeout = get_tree().create_tween()
	fadeout.tween_property($Slide2/Background4,"modulate", Color("000000"), 1)
	fadeout.finished.connect(changeScene)


	
func changeScene():
	get_tree().change_scene_to_file("res://IntroCutscene.tscn")

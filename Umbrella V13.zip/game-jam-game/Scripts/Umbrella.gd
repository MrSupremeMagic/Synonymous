extends CharacterBody2D

@onready var anim = $AnimatedSprite2D
@onready var particles = $CPUParticles2D

@onready var audio_player = $AudioStreamPlayer2D

const SPEED = 300.0
const JUMP_VELOCITY = -800.0
const OPEN_RES = 10
const CLOSED_RES = 0.25

var swooshOpen = load("res://Sounds/Umbrella.wav")
var woosh = load("res://Sounds/woosh.wav")

var gliding = false
var holdingJump = false
var open = false
var currentPos:Vector2

signal position_updated(pos: Vector2)

func open_umbrella():
	if not open:
		open = true
		anim.play("Open", 3)
		
func close_umbrella():
	if open:
		audio_player.stream = woosh
		audio_player.play()
		open = false
		anim.play("Close", 3)

func _ready() -> void:
	print(get_tree().current_scene.name)
	AudioController.play_bg_music()
	anim.play("Close")
	var fadeTween = get_tree().create_tween()
	fadeTween.tween_property($TextureRect, "modulate", Color("ffffff00") , 1)


func _physics_process(delta: float) -> void:
	
	
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
		if not gliding:
			close_umbrella()

	#Air resistance
	if not is_on_floor():
		if gliding:
			if velocity.y > 0:
				var change = abs(velocity.y*OPEN_RES*delta)
				velocity.y -= change
			else:
				var change = abs(velocity.y*OPEN_RES*delta)
				velocity.y += change
		else:
			if velocity.y > 0:
				var change = abs(velocity.y*CLOSED_RES*delta)
				velocity.y -= change
			else:
				var change = abs(velocity.y*CLOSED_RES*delta)
				velocity.y += change


	# Handle jump.
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		open_umbrella()
		holdingJump = true
		anim.play("Spin", 4)
		await get_tree().create_timer(0.5).timeout
		if holdingJump:
			
			velocity.y = JUMP_VELOCITY
			particles.emitting = true
			holdingJump = false
	
	if not is_on_floor() and not gliding and not holdingJump:
		close_umbrella()
	
	if Input.is_action_just_released("ui_accept"):
		holdingJump = false
		
		close_umbrella()
		
	
	if Input. is_action_just_pressed("ui_accept") and not is_on_floor():
		#velocity.y = 30;
		anim.play("Spin", 1)
		gliding = true
		audio_player.stream = swooshOpen
		audio_player.play()
		open = true
	

	if Input. is_action_just_released("ui_accept"):
		gliding = false
		close_umbrella()

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var leftRight := Input.get_axis("ui_left", "ui_right")
	
	if abs(velocity.x)>200:
		var tween = get_tree().create_tween()
		tween.tween_property(anim, "rotation", leftRight*0.2, 0.15)
	
	if leftRight:
		emit_signal("position_updated", position)
		velocity.x = leftRight * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()



func _on_death_plane_body_entered(body: Node2D) -> void:
	if body == self:
		get_tree().reload_current_scene()


func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.collision_layer == 4:
		get_tree().reload_current_scene()


func _on_area_2d_area_entered(area: Area2D) -> void:
	exiting()

func exiting():
	var fadeTween = get_tree().create_tween()
	fadeTween.tween_property($TextureRect, "modulate", Color("000000ff") , 1)
	await get_tree().create_timer(1.2).timeout
	if get_tree().current_scene.name == "Level 1":
		get_tree().change_scene_to_file("res://Level_2.tscn")
	
